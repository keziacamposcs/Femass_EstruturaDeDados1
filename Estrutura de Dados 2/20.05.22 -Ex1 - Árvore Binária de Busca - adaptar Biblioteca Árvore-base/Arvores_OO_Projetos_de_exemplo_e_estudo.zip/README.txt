Esta pasta contém 2 projetos de Árvores de Busca Binária desenvolvidas em C++ e orientada a objetos:

- "Prj_Arv_BinariaOO_Base" - usa struct para definir nó-dado e possui alguns métodos básicos, resumidos, de mais fácil entendimento geral. Adaptações e referências estão em comentários no main.cpp.

- "Prj_ArvBin_Livro_Adam_Drozdek_Adaptado" - usa uma classe para definição de objeto nó-dado, que por sua vez é invocado por outra classe de controle da árvore e seus métodos (maior variedade e complexidade). A prototipação OO merece de melhorias e algumas adaptações foram feitas do original de referência - Livro: Drozdek, A., Estrutura de dados e algoritmos em C++. São Paulo, SP: Cengage Learning, 2016. Cap. 6.

