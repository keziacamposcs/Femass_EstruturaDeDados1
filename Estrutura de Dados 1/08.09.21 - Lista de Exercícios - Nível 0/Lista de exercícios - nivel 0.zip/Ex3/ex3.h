int* cadastrarnumero(int *vvetor, int *n);
void exibir(int *vvetor, int n);
void exibirquant(int n);
int* removerult(int* vvetor, int *n);

