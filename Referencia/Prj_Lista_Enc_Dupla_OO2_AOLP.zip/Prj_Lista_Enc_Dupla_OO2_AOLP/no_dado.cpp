//no_dado.cpp
#include "no_dado.h"
#include <stdlib.h>

no_dado::no_dado(int _valor){
	info = _valor;
	ant = NULL;
	prox = NULL;
}
