//no_dado.h

class no_dado{
	public:
		int info;
		no_dado* prox; 
	public:
		no_dado(); //construtor
		no_dado(int i, no_dado* l);
			
};
